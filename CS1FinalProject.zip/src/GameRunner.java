import javax.swing.JFrame;

/**
 * Main driver class.
 */
public class GameRunner {

	public static void main(String[] args) {
		String file = null;

		TitleScreen game = new TitleScreen();
		game.run();

		switch(game.getCharacter()) {
		case 1:
			file = "hero1.png";
			break;
		case 2:
			file = "hero2.png";
			break;
		case 3:
			file = "hero3.png";
			break;
		}

		IslandScreen island = new IslandScreen();
		island.run();

		switch(island.getChosenIsland()) {
		case 1:
			MushroomLevel maze1 = new MushroomLevel(new Hero(file, 0, 30, 2, "myHero"));
			maze1.run();

			MushroomLevelBossFight level1 = new MushroomLevelBossFight();

			Enemy mushroomBoss = new Enemy("mushroomBoss.png", 200, 100, 10, 50);
			mushroomBoss.activate();

			level1.addHero(new Hero(file, 100, 300, 7, "myHero"));
			level1.addEnemy(mushroomBoss);
			level1.run();

			break;
		case 2:
			CrystalLevel maze2 = new CrystalLevel(new Hero(file, 0, 30, 2, "myHero"));
			maze2.run();

			CrystalLevelBossFight level2 = new CrystalLevelBossFight();

			Enemy crystalBoss = new Enemy("crystalBoss.png", 200, 100, 10, 50);
			crystalBoss.activate();

			level2.addHero(new Hero(file, 100, 300, 7, "myHero"));
			level2.addEnemy(crystalBoss);

			level2.run();

			break;
		case 3:
			IceLevel maze3 = new IceLevel(new Hero(file, 0, 30, 2, "myHero"));
			maze3.run();

			IceLevelBossFight level3 = new IceLevelBossFight();

			Enemy iceBoss = new Enemy("iceBoss.png", 200, 100, 10, 50);
			iceBoss.activate();

			level3.addHero(new Hero(file, 100, 300, 7, "myHero"));
			level3.addEnemy(iceBoss);

			level3.run();

			break;
		default:
			System.exit(0);
		}
	}
}
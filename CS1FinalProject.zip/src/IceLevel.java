import java.awt.*;

import javax.swing.*;

public class IceLevel extends Game {

	/**
	 * This defines the ice island.
	 * @param h
	 */
	public IceLevel(Hero h) {
		super();
		
		Obstacle maze = new Obstacle(21, 15, "grass.png", "wall.png", this);
		maze.setBounds(60, 50, maze.getPreferredSize().width, maze.getPreferredSize().height);
		
		addHero(h);
		h.setObstacle(maze);
		
		addItem(new Item("Coin.png", 648, 424, 5));
		add(maze);
	}

	@Override
	public BackgroundPanel setBackground() {
		return new BackgroundPanel("game_background_1.png");
	}
	
	
}
